package zoo;

import java.io.Serializable;

public class animal implements Serializable {
	
	String code;
	String name;
	String type;
	String kg;
	String max_age;
	String gen;
	
	public void sayH() {
		
		 System.out.println("Animal : " + name);
		 
	}

}
