package zoo;

import javax.swing.JFrame;

import javax.swing.JOptionPane;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.text.TableView.TableRow;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;



public class frame extends JFrame implements ActionListener {

	
	
	public static int temp;
	
	public static String temps;

	JButton b1 = new JButton();             //initialize buttons
	JButton b2 = new JButton();
	JButton b3 = new JButton();
	JButton b4 = new JButton();
	JButton b5 = new JButton();
	JButton b6 = new JButton();
	JButton bmenu = new JButton();

	JPanel p1 = new JPanel();                 //initialize panels
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();
	JPanel p5 = new JPanel();
	JPanel p6 = new JPanel();
	JPanel menu = new JPanel();

	JPanel op1 = new JPanel();
	JPanel op2 = new JPanel();
	JPanel op3 = new JPanel();
	JPanel op4 = new JPanel();
	JPanel op5 = new JPanel();
	JPanel op6 = new JPanel();

	

	JTextField name = new JTextField();        //initialize textfields for new animal creation
	JTextField code = new JTextField();
	JTextField type = new JTextField();
	JTextField kg = new JTextField();
	JTextField age = new JTextField();
	JTextField gen = new JTextField();
	
	JButton submit1 = new JButton();           //initialize submit buttons
	JButton submit2 = new JButton();
	JButton submit3 = new JButton();
	JButton submit4 = new JButton();
	JButton submit5 = new JButton();
	JButton submit6 = new JButton();
	
	JTextField TEMP = new JTextField();           //initialize textfields for getting temporary information
	JTextField TEMP2 = new JTextField(); 
	JTextField TEMP3 = new JTextField();
	JTextField TEMP4 = new JTextField();
	
	 
    int tempi;    //variable that hold info 
	
	

	JPanel menu1 = new JPanel();

	JLabel logoz = new JLabel();

	ImageIcon image = new ImageIcon("assets/logo.png");      // basic assets
	ImageIcon pix = new ImageIcon("assets/pixel.png");
	ImageIcon back = new ImageIcon("assets/back.png");
	
	
	
	
	String [] columnNames = {"Name","Code","Type","Weight","Max Age", "Gender"};    
	
	
	 DefaultTableModel model = new DefaultTableModel();     //table model --> easier to edit 
	 DefaultTableModel model2 = new DefaultTableModel();
	 DefaultTableModel model3 = new DefaultTableModel();
	
	JTable table = new JTable(model);	
	JTable table2 = new JTable(model2);
	JTable table3 = new JTable(model3);
	

	
	ArrayList<String> DB = new ArrayList<>();     //1D array list to search animals base on code/name
	
	
	int i;    //number of animals 
	
	

	

	File animalss = new File("Animals/");    //fnames -> name of each animal file
	
	String fnames[]= animalss.list();
    
    animal tanimal = new animal();
	
	Object[] obj = new Object[6];
	
	
	
	frame() {
		
        
		
		
		table.setEnabled(false);               // creation of models for tables 1 2 3 
		table2.setEnabled(false);
		table3.setEnabled(false);
		
		
		
		
		model.addColumn("Name"); 
		model.addColumn("Code"); 
		model.addColumn("Type"); 
		model.addColumn("Weight"); 
		model.addColumn("Max Age");         
		model.addColumn("Gender"); 
		
		model2.addColumn("Name"); 
		model2.addColumn("Code"); 
		model2.addColumn("Type"); 
		model2.addColumn("Weight"); 
		model2.addColumn("Max Age"); 
		model2.addColumn("Gender"); 
		
		obj[0]=" ";
		obj[1]=" ";
		obj[2]=" ";
		obj[3]=" ";
		obj[4]=" ";
		obj[5]=" ";
		
		
		model2.addRow(obj);
		
		
		
		model3.addColumn("Name"); 
		model3.addColumn("Code"); 
		model3.addColumn("Type"); 
		model3.addColumn("Weight"); 
		model3.addColumn("Max Age"); 
		model3.addColumn("Gender"); 
		
		model3.addRow(obj);
		
		
		DBCreate();
	    
	    
	  
		
	
        
		name.addMouseListener(new MouseAdapter() {      // when user clicks textfields with base text -> blank
			  @Override  
			  public void mouseClicked(MouseEvent e) {				  
				     String text = name.getText();				     
				     if(text.equals("Animal Name")) {name.setText("");}    	     				     				     			   
			  }
			});
		
		code.addMouseListener(new MouseAdapter() {
			  @Override
			  public void mouseClicked(MouseEvent e) {				  
				     String text = code.getText();				     
				     if(text.equals("Animal Code")) {code.setText("");}    	     				     				     			   
			  }
			});
		type.addMouseListener(new MouseAdapter() {
			  @Override
			  public void mouseClicked(MouseEvent e) {				  
				     String text = type.getText();				     
				     if(text.equals("Animal Type")) {type.setText("");}    	     				     				     			   
			  }
			});
		kg.addMouseListener(new MouseAdapter() {
			  @Override
			  public void mouseClicked(MouseEvent e) {				  
				     String text = kg.getText();				     
				     if(text.equals("Animal Weight")) {kg.setText("");}    	     				     				     			   
			  }
			});
		age.addMouseListener(new MouseAdapter() {
			  @Override
			  public void mouseClicked(MouseEvent e) {				  
				     String text = age.getText();				     
				     if(text.equals("Animal Maximum Age")) {age.setText("");}    	     				     				     			   
			  }
			});
		gen.addMouseListener(new MouseAdapter() {
			  @Override
			  public void mouseClicked(MouseEvent e) {				  
				     String text = gen.getText();				     
				     if(text.equals("Animal Gender(F/M)")) {gen.setText("");}    	     				     				     			   
			  }
			});
		
		TEMP.addMouseListener(new MouseAdapter() {
			  @Override
			  public void mouseClicked(MouseEvent e) {				  
				     String text = TEMP.getText();				     
				     if(text.equals("Give Me Name")) {TEMP.setText("");}    	     				     				     			   
			  }
			});
		
		TEMP2.addMouseListener(new MouseAdapter() {
			  @Override
			  public void mouseClicked(MouseEvent e) {				  
				     String text = TEMP2.getText();				     
				     if(text.equals("Give Me Code")) {TEMP2.setText("");}    	     				     				     			   
			  }
			});
		TEMP3.addMouseListener(new MouseAdapter() {
			  @Override
			  public void mouseClicked(MouseEvent e) {				  
				     String text = TEMP3.getText();				     
				     if(text.equals("Give Me Code")) {TEMP3.setText("");}    	     				     				     			   
			  }
			});
		TEMP4.addMouseListener(new MouseAdapter() {
			  @Override
			  public void mouseClicked(MouseEvent e) {				  
				     String text = TEMP4.getText();				     
				     if(text.equals("Give Me Code")) {TEMP4.setText("");}    	     				     				     			   
			  }
			});
		
		this.setSize(1300, 700);
		this.setTitle("");
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
 
		p1.setPreferredSize(new Dimension(100, 140));     // making the basic layout
		p2.setPreferredSize(new Dimension(100, 100));     
		p3.setPreferredSize(new Dimension(100, 100));
		p4.setPreferredSize(new Dimension(100, 100));
		p5.setPreferredSize(new Dimension(100, 100));

		op1.setPreferredSize(new Dimension(400, 450));
		op2.setPreferredSize(new Dimension(900, 450));
		op3.setPreferredSize(new Dimension(600, 250));
		op4.setPreferredSize(new Dimension(600, 250));
		op5.setPreferredSize(new Dimension(400, 450));
		op6.setPreferredSize(new Dimension(400, 250));

		
		
		
		table.setFillsViewportHeight(true);
		
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		
       
		
		
		
		
		
		
		JScrollPane pane = new JScrollPane(table);   //scrollpane so table is scrollable
		JScrollPane pane2 = new JScrollPane(table2);
		JScrollPane pane3 = new JScrollPane(table3);
		
		
		
		op2.add(pane);
	
		
		
		op1.setLayout(new BoxLayout(op1, BoxLayout.PAGE_AXIS));
		
		op3.setLayout(new BoxLayout(op3, BoxLayout.PAGE_AXIS));   //creating interface for each action 
		op4.setLayout(new BoxLayout(op4, BoxLayout.PAGE_AXIS));
		op5.setLayout(new BoxLayout(op5, BoxLayout.PAGE_AXIS));
		op6.setLayout(new BoxLayout(op6, BoxLayout.PAGE_AXIS));
		
		submit2.setAlignmentX(Component.CENTER_ALIGNMENT);
	    submit2.setText("Search");
	    TEMP.setText("Give Me Name");
	    TEMP.setHorizontalAlignment(JTextField.CENTER);
	    TEMP2.setText("Give Me Code");
	    TEMP2.setHorizontalAlignment(JTextField.CENTER);
	    TEMP3.setText("Give Me Code");
	    TEMP3.setHorizontalAlignment(JTextField.CENTER);
	    TEMP4.setText("Give Me Code");
	    TEMP4.setHorizontalAlignment(JTextField.CENTER);
	    
		
		
		op3.add(Box.createRigidArea(new Dimension(1, 50)));
		op3.add(TEMP);
		op3.add(Box.createRigidArea(new Dimension(1, 50)));
		op3.add(pane2);
		op3.add(Box.createRigidArea(new Dimension(1, 50)));
		op3.add(submit2);
		
		op4.add(Box.createRigidArea(new Dimension(1, 50)));
		op4.add(TEMP2);
		op4.add(Box.createRigidArea(new Dimension(1, 50)));
		op4.add(pane3);
		op4.add(Box.createRigidArea(new Dimension(1, 50)));
		op4.add(submit3);
		

		op5.add(Box.createRigidArea(new Dimension(1, 100)));
		op5.add(TEMP3);
		op5.add(Box.createRigidArea(new Dimension(1, 150)));
		op5.add(submit4);
		op5.add(Box.createRigidArea(new Dimension(1, 200)));
		

		op6.add(Box.createRigidArea(new Dimension(1, 100)));
		op6.add(TEMP4);
		op6.add(Box.createRigidArea(new Dimension(1, 100)));	
		op6.add(submit5);
		

		p2.add(bmenu);
		p2.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 0));
		bmenu.setVisible(false);

		menu.setPreferredSize(new Dimension(600, 150));
		menu1.setPreferredSize(new Dimension(1000, 30));

		menu.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 15));

		b1.setText("SHOW ALL ANIMALS");      
		b2.setText("ADD ANIMAL");
		b3.setText("SEARCH BY NAME");
		b4.setText("SEARCH BY CODE");
		b5.setText("CHANGE ANIMAL INFO");
		b6.setText("DELETE ANIMAL");
		bmenu.setIcon(back);
		
		
		

		b1.setBackground(new Color(0, 137, 255));
		b2.setBackground(new Color(0, 137, 255));
		b3.setBackground(new Color(0, 137, 255));
		b4.setBackground(new Color(0, 137, 255));
		b5.setBackground(new Color(0, 137, 255));
		b6.setBackground(new Color(0, 137, 255));
		bmenu.setBackground(new Color(0, 137, 255));

		bmenu.setBorderPainted(false);
		bmenu.setContentAreaFilled(false);
		bmenu.setFocusPainted(false);
		bmenu.setOpaque(false);

		b1.setForeground(Color.white);
		b2.setForeground(Color.white);
		b3.setForeground(Color.white);
		b4.setForeground(Color.white);
		b5.setForeground(Color.white);
		b6.setForeground(Color.white);
		bmenu.setForeground(Color.white);

		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		b4.addActionListener(this);
		b5.addActionListener(this);
		b6.addActionListener(this);
		bmenu.addActionListener(this);
		submit1.addActionListener(this);
		submit2.addActionListener(this);
		submit3.addActionListener(this);
		submit4.addActionListener(this);
		submit5.addActionListener(this);
		submit6.addActionListener(this);

		b1.setPreferredSize(new Dimension(160, 50));
		b2.setPreferredSize(new Dimension(160, 50));
		b3.setPreferredSize(new Dimension(160, 50));
		b4.setPreferredSize(new Dimension(160, 50));
		b5.setPreferredSize(new Dimension(160, 50));
		b6.setPreferredSize(new Dimension(160, 50));
		bmenu.setPreferredSize(new Dimension(100, 100));

		menu.add(b1);
		menu.add(b2);
		menu.add(b3);
		menu.add(b4);
		menu.add(b5);
		menu.add(b6);
		
		code.setPreferredSize(new Dimension(50,30));
		kg.setPreferredSize(new Dimension(50,30));
		name.setPreferredSize(new Dimension(50,30));
		age.setPreferredSize(new Dimension(50,30));
		gen.setPreferredSize(new Dimension(50,30));
		type.setPreferredSize(new Dimension(50,30));


		p5.add(menu, BorderLayout.CENTER);
		p5.add(op1, BorderLayout.CENTER);
		p5.add(op2, BorderLayout.CENTER);
		p5.add(op3, BorderLayout.CENTER);
		p5.add(op4, BorderLayout.CENTER);
		p5.add(op5, BorderLayout.CENTER);
		p5.add(op6, BorderLayout.CENTER);

		op1.setVisible(false);
		op2.setVisible(false);
		op3.setVisible(false);
		op4.setVisible(false);
		op5.setVisible(false);
		op6.setVisible(false);

		this.setIconImage(pix.getImage());

		this.getContentPane().setBackground(new Color(234, 234, 234));

		logoz.setIcon(image);

		this.add(p1, BorderLayout.NORTH);
		this.add(p2, BorderLayout.WEST);
		this.add(p3, BorderLayout.EAST);
		this.add(p5, BorderLayout.CENTER);

		
		
		

		name.setBackground(new Color(0, 137, 255));
		kg.setBackground(new Color(0, 137, 255));
		age.setBackground(new Color(0, 137, 255));
		type.setBackground(new Color(0, 137, 255));
		code.setBackground(new Color(0, 137, 255));
		gen.setBackground(new Color(0, 137, 255));
		TEMP.setBackground(new Color(0, 137, 255));
		TEMP2.setBackground(new Color(0, 137, 255));
		TEMP3.setBackground(new Color(0, 137, 255));
		TEMP4.setBackground(new Color(0, 137, 255));

		
		name.setForeground(Color.white);
		kg.setForeground(Color.white);
		age.setForeground(Color.white);
		type.setForeground(Color.white);
		code.setForeground(Color.white);
		gen.setForeground(Color.white);
		TEMP.setForeground(Color.white);
		TEMP2.setForeground(Color.white);
		TEMP3.setForeground(Color.white);
		TEMP4.setForeground(Color.white);
		
		
		
		
		name.setHorizontalAlignment(JTextField.CENTER);
		kg.setHorizontalAlignment(JTextField.CENTER);
		age.setHorizontalAlignment(JTextField.CENTER);
		type.setHorizontalAlignment(JTextField.CENTER);
		code.setHorizontalAlignment(JTextField.CENTER);
		gen.setHorizontalAlignment(JTextField.CENTER);

		submit1.setAlignmentX(Component.CENTER_ALIGNMENT);
		submit1.setText("Save Animal");
		
		submit2.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		
		submit3.setAlignmentX(Component.CENTER_ALIGNMENT);
		submit3.setText("Search");
		
		submit4.setAlignmentX(Component.CENTER_ALIGNMENT);
		submit4.setText("Search");
		
		submit5.setAlignmentX(Component.CENTER_ALIGNMENT);
		submit5.setText("Delete Animal");
		 
		submit6.setAlignmentX(Component.CENTER_ALIGNMENT);
		submit6.setText("Save Animal");
		
		submit1.setBackground(Color.green);
		submit1.setContentAreaFilled(false);
		submit1.setForeground(Color.black);
		submit1.setPreferredSize(new Dimension(100,25));
		
		submit6.setBackground(Color.green);
		submit6.setContentAreaFilled(false);
		submit6.setForeground(Color.black);
		submit6.setPreferredSize(new Dimension(100,25));

		p1.add(logoz, BorderLayout.CENTER);

		
		
		this.revalidate();

	}
	
	public void onSubName() {        //finds the location of a name in the DB and the corresponding data 
		 // saves the location to global x 
		String temps;
		int x;
		temps=TEMP.getText();
		boolean bool=true;
		
		if(temps.equals("Give Me Name")) {
			JOptionPane.showMessageDialog(null,"Enter a valid name.");
		}else {
			
			int rowCount= model2.getRowCount();
				for (int i = rowCount - 1; i >= 0; i--) {
					model2.removeRow(i);
				}
				
			for(x=0; x<i;x++) {
				
				System.out.println(DB.get(x*6));
				if(DB.get(x*6).equals(temps)) {
					
					
					System.out.println("to vrika");

					
					
					obj[0]=DB.get(x*6);
					obj[1]=DB.get(x*6+1);
					obj[2]=DB.get(x*6+2);
					obj[3]=DB.get(x*6+3);
					obj[4]=DB.get(x*6+4);
					obj[5]=DB.get(x*6+5);
					
					bool=false;
					model2.addRow(obj);
					
				}
				
				
				
			}
			
			
			
		}
		
		if(bool) {
		JOptionPane.showMessageDialog(null,"No animal with that name found.");}
		
		
		
		
		
		
	};
	
public void onSubCode() {    //finds the location of a code in the DB and the corresponding data 
	 // saves the location to global x 
		
		String temps;
		int x=0;
		temps=TEMP2.getText();
		boolean bool=true;
		if(temps.equals("Give Me Code")) {
			JOptionPane.showMessageDialog(null,"Enter a valid Code.");
		}else {
			
			int rowCount= model3.getRowCount();
				for (int i = rowCount - 1; i >= 0; i--) {
					model3.removeRow(i);
				}
				
			for(x=0; x<i;x++) {
				
				if(DB.get(x*6+1).equals(temps)) {
					
					
					System.out.println("to vrika");

					
					
					obj[0]=DB.get(x*6);
					obj[1]=DB.get(x*6+1);
					obj[2]=DB.get(x*6+2);
					obj[3]=DB.get(x*6+3);
					obj[4]=DB.get(x*6+4);
					obj[5]=DB.get(x*6+5);
					
					
					model3.addRow(obj);
					bool=false;
					break;
					
				}
				
				
				
			}
			
			
			
		}
		
		if(bool) {
			JOptionPane.showMessageDialog(null,"No animal with that code found.");}
		
		
		
		
	};
	
	public int onSubS() {
		//finds the location of a code in the DB and the corresponding data 
		 // saves the location to global x 
		//returns x to -> animal number in db -> edit
		
		String temps;
		boolean flag=false;
		int x=0;
		temps=TEMP3.getText();
		
		if(temps.equals("Give Me Code")) {
			JOptionPane.showMessageDialog(null,"Enter a valid Code.");
		}else {
			
		
				
			for(x=0; x<i;x++) {
				
				if(DB.get(x*6+1).equals(temps)) {
					
				
					flag=true;
					
					break;
					
				}
				
				
				
			}
			
			
			
		}
		
		
		if(flag) {
		return x;
		}else {
			
				
			return -1;
		}
	};
	
	public int onSubD() {
		
		//finds the location of a code in the DB and the corresponding data 
		 // saves the location to global x 
		//returns x to -> animal number in db -> delete
		String temps;
		boolean flag=false;
		int x=0;
		temps=TEMP4.getText();
		
		
			
		
				
			for(x=0; x<i;x++) {
				
				if(DB.get(x*6+1).equals(temps)) {
				
					
					
				
					flag=true;
					
					break;
					
				}
				
				
				
			}
			
			
			
		
		
		
		if(flag) {
		return x;
		}else {
			return -1;
		}
	};
	
	public void onSub()  {
		//creates new animal 
		
		boolean bool = true;
		for(int x=0; x<i ;x++) { //checks that code is unique 
			if(DB.get(x*6+1).equals(code.getText())) {
				
				
					bool=false;
			
				
				
				
			}
			
		};
		if(bool) {
		if(kg.getText().matches("[0-9]+") & age.getText().matches("[0-9]+") & (gen.getText().equals("F") || gen.getText().equals("M") ) ){
			//checks that data is typed correctly
			animal anim = new animal();
			
			anim.name = name.getText();
			anim.code = code.getText();
			anim.type = type.getText();
			anim.kg   = kg.getText();
			anim.max_age = age.getText();
			anim.gen  = gen.getText();
			
			System.out.print("DONE");	
			
			FileOutputStream fileOut = null;   //makes a new file with the data of the new animal
			try {
				i=i+1;
				fileOut = new FileOutputStream("Animals/TestAnimal"+i+".ser");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			ObjectOutputStream out=null;
			try {
				out = new ObjectOutputStream(fileOut);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				out.writeObject(anim);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				fileOut.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			showm(2);
			JOptionPane.showMessageDialog(null,"Animal Saved Successfully");
			
			//updates database and table
			
			obj[0]=anim.name;
			obj[1]=anim.code;
			obj[2]=anim.type;
			obj[3]=anim.kg;
			obj[4]=anim.max_age;
			obj[5]=anim.gen;
			
			
			DB.add(anim.name);
			DB.add(anim.code);
			DB.add(anim.type);
			DB.add(anim.kg);
			DB.add(anim.max_age);
			DB.add(anim.gen);
			
			
			
		    
			
			model.addRow(obj);
			
			
			
		}else {
			JOptionPane.showMessageDialog(null,"Check that max age and weight are number or that gender is either F or M.");
		}
		
		
	    
		
		}else {
			JOptionPane.showMessageDialog(null,"Add unique code.");
		}
		
		
	};
	
	
	public void onSub2(String co) {
		//edits animal
		
    if(kg.getText().matches("[0-9]+") & age.getText().matches("[0-9]+") & (gen.getText().equals("F") || gen.getText().equals("M") ) ){
			
			animal anim = new animal();
			
			anim.name = name.getText();
			anim.code = code.getText();
			anim.type = type.getText();
			anim.kg   = kg.getText();
			anim.max_age = age.getText();
			anim.gen  = gen.getText();
			
			System.out.print("DONE");	
			
			FileOutputStream fileOut = null;
			try {
				
				fileOut = new FileOutputStream("Animals/"+fnames[tempi]); //replaces the animal file with a new one that has the updated data
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			ObjectOutputStream out=null;
			try {
				out = new ObjectOutputStream(fileOut);
			} catch (IOException e) {
				 // TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				out.writeObject(anim);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				out.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				fileOut.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			showm(5);
			
			
			//updates database and table with new data
			
			DB.set(tempi*6, anim.name);
			DB.set(tempi*6+1, anim.code);
			DB.set(tempi*6+2, anim.type);
			DB.set(tempi*6+3, anim.kg);
			DB.set(tempi*6+4, anim.max_age);
			DB.set(tempi*6+5, anim.gen);
			
			
			table.setValueAt(anim.name, tempi, 0);
			table.setValueAt(anim.code, tempi, 1);
			table.setValueAt(anim.type, tempi, 2);
			table.setValueAt(anim.kg, tempi, 3);
			table.setValueAt(anim.max_age, tempi, 4);
			table.setValueAt(anim.gen, tempi, 5);
			
			
			
			
			
			
			
			
		    
			
			
			
			
		}else {
			JOptionPane.showMessageDialog(null,"Check that max age and weight are number or that gender is either F or M.");
		}
    
	
	}
	
	

	public void actionPerformed(ActionEvent e) { 

		if (e.getSource() == b1) {
			temp = 1;
			
			
			
			hidem(temp);

		}

		if (e.getSource() == b2) {
			temp = 2;
			   name.setText("Animal Name");
				kg.setText("Animal Weight");
				age.setText("Animal Maximum Age");
				type.setText("Animal Type");
				code.setText("Animal Code");
				gen.setText("Animal Gender(F/M)");
		    op1.removeAll();    //uses submit1 ->create
			op1.add(Box.createRigidArea(new Dimension(1, 25)));
			op1.add(name);
			op1.add(Box.createRigidArea(new Dimension(1, 25)));
			op1.add(kg);
			op1.add(Box.createRigidArea(new Dimension(1, 25)));
			op1.add(age);
			op1.add(Box.createRigidArea(new Dimension(1, 25)));
			op1.add(type);
			op1.add(Box.createRigidArea(new Dimension(1, 25)));
			op1.add(code);
			op1.add(Box.createRigidArea(new Dimension(1, 25)));
			op1.add(gen);
			op1.add(Box.createRigidArea(new Dimension(1, 25)));
			op1.add(submit1);
			op1.revalidate();
			hidem(temp);
		}

		if (e.getSource() == b3) {
			TEMP.setText("Give Me Name");
			temp = 3;
			hidem(temp);
			
		}

		if (e.getSource() == b4) {
			TEMP2.setText("Give Me Code");
			temp = 4;
			hidem(temp);

		}

		if (e.getSource() == b5) {
			TEMP3.setText("Give Me Code");
			temp = 5;
			hidem(temp);
		}

		if (e.getSource() == b6) {
			TEMP4.setText("Give Me Code");
			temp = 6;
			hidem(temp);
		}

		if (e.getSource() == bmenu) {

			showm(temp);
		}
		
		if (e.getSource() == name) {

			name.setText("");
		}
		
		if(e.getSource() == submit1) {
			
			System.out.println("ONsub");
			
			onSub();
			
		}
		
        if(e.getSource() == submit2) {
			
			System.out.println("ONsubName");
			
			onSubName();
			
		}
        

        if(e.getSource() == submit3) {
			
			System.out.println("ONsubCode");
			
			onSubCode();
			
		}
        
        if(e.getSource() == submit4) {
			
			System.out.println("sub4");
			
			tempi=onSubS();
			
			if(tempi>=0) {
			System.out.println(fnames[tempi]);
			
			op5.setVisible(false);
			
			op1.removeAll();//uses submit6 -> edit
			op1.add(Box.createRigidArea(new Dimension(1, 25)));
			op1.add(name);
			op1.add(Box.createRigidArea(new Dimension(1, 25)));
			op1.add(kg);
			op1.add(Box.createRigidArea(new Dimension(1, 25)));
			op1.add(age);
			op1.add(Box.createRigidArea(new Dimension(1, 25)));
			op1.add(type);
			op1.add(Box.createRigidArea(new Dimension(1, 25)));
			op1.add(code);
			op1.add(Box.createRigidArea(new Dimension(1, 25)));
			op1.add(gen);
			op1.add(Box.createRigidArea(new Dimension(1, 25)));
			op1.add(submit6);
			
			
			
			
			
			
			
			op1.setVisible(true);
			
			FileInputStream fileIn = null;
			try {
				fileIn = new FileInputStream("Animals/"+fnames[tempi]);
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			ObjectInputStream in = null;
			try {
				in = new ObjectInputStream(fileIn);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			try {
				tanimal = (animal) in.readObject();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			submit6.addActionListener(new ActionListener() { 
				  public void actionPerformed(ActionEvent e) { 
					    onSub2(tanimal.code);
					  } 
					} );
			
			op1.revalidate();
			
			name.setText(tanimal.name);
			kg.setText(tanimal.kg);
			age.setText(tanimal.max_age);
			type.setText(tanimal.type);
			code.setText(tanimal.code);
			gen.setText(tanimal.gen); 
			
			
			
			try {
				in.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				fileIn.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
			
			DB.clear();    
			model.setRowCount(0);
			DBCreate();
			
			
			}else {
				JOptionPane.showMessageDialog(null,"No animal with that code found.");
			}
		}

        if(e.getSource() == submit5) {
	
	    System.out.println("sub5");
	   
	    
	    tempi=onSubD();
	    if(tempi>=0) {
	    String tempfn=fnames[tempi];
	    System.out.println(tempi);
	    
	     
	    for(int x=tempi ; x< i ; x++) {    //deletes the file and updates the file names 
	    	 
	    	if(x==tempi) {
	    	File file= new File("Animals/"+tempfn);
	    
	    	file.delete();
	    	}else {
	    		Path dir =  Paths.get("Animals/"+fnames[x]);	
	    		
	    	try {
	    		
				Files.move(dir, dir.resolveSibling(tempfn));
				tempfn=fnames[x];
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	    		
	    	
	    	}
	    	
	    	
	    }
	    
	    i=i-1;
	    
	    DB.clear();
	    System.out.println("DB:"+DB);
	    model.setRowCount(0);
	    
	    DBCreate();
	   
	    System.out.println("FNAMES:");
	    for(int x = 0 ; x < fnames.length ; x++) {
	    System.out.println(fnames[x]);
	    };
	    JOptionPane.showMessageDialog(null,"Deleted animal.");
	    
	    }else{
	    	JOptionPane.showMessageDialog(null,"No animal with that code found.");
		};
	
	    
	    
	    
	
}
		

    
        
	}
	
	public void DBCreate() { //creates database with animal data
		
		

		
		
		List<String> fileNames = new ArrayList<>();
	    try {
	      DirectoryStream<Path> directoryStream = Files.newDirectoryStream(Paths.get("Animals/"));
	      for (Path path : directoryStream) {
	        fileNames.add(path.toString());
	      }
	    } catch (IOException ex) {
	    }
	    
	    i= fileNames.size();
	    
	    for(int x=0; x<i ; x++) {
	    	
	    	System.out.println(fnames[x]);
	    	
	    	FileInputStream fileIn = null;
			try {
				fileIn = new FileInputStream("Animals/"+fnames[x]);
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			ObjectInputStream in = null;
			try {
				in = new ObjectInputStream(fileIn);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			try {
				tanimal = (animal) in.readObject();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			try {
				in.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				fileIn.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
			
			obj[0]=tanimal.name;
			obj[1]=tanimal.code;
			obj[2]=tanimal.type;
			obj[3]=tanimal.kg;
			obj[4]=tanimal.max_age;
			obj[5]=tanimal.gen;
			
			
			DB.add(tanimal.name);
			DB.add(tanimal.code);
			DB.add(tanimal.type);
			DB.add(tanimal.kg);
			DB.add(tanimal.max_age);
			DB.add(tanimal.gen);
			
			
			
		    
			
			model.addRow(obj);
			
	    	
	    
			
			
	    }
	    
	    System.out.println("db is:" +DB);
	  
		
	}

	public void showm(int temp) {  //changes interface

		menu.setVisible(true);

		bmenu.setVisible(false);
		p6.setVisible(false);

		if (temp == 2) {
			op1.setVisible(false);
		} else if (temp == 1) {
			op2.setVisible(false);
		} else if (temp == 3) {
			op3.setVisible(false);
		} else if (temp == 4) {
			op4.setVisible(false);
		} else if (temp == 5) {
			op5.setVisible(false);
			op1.setVisible(false);
		} else if (temp == 6) {
			op6.setVisible(false);
		}

	}

	public void hidem(int temp) {

		menu.setVisible(false);
		bmenu.setVisible(true);
		p6.setVisible(true);

		if (temp == 2) {
			op1.setVisible(true);
		} else if (temp == 1) {
			op2.setVisible(true);
		} else if (temp == 3) {
			op3.setVisible(true);
		} else if (temp == 4) {
			op4.setVisible(true);
		} else if (temp == 5) {
			op5.setVisible(true);
		} else if (temp == 6) {
			op6.setVisible(true);
		}

	}

}
