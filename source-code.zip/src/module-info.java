module zoo {
	requires java.desktop;
}